import React from 'react'
import { Outlet, Link } from 'react-router-dom'
import './AdminLayout.css'

function AdminLayout() {
  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <h2>Administration</h2>
        <nav>
          <ul>
            <li><Link to="/admin">Personnages</Link></li>
            {/* Ajoutez d'autres liens de navigation ici */}
          </ul>
        </nav>
      </aside>
      <main className="admin-content">
        <Outlet />
      </main>
    </div>
  )
}

export default AdminLayout