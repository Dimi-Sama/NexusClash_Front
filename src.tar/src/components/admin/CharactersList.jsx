import React from 'react'
import { Link } from 'react-router-dom'

function CharactersList() {
  // Simulons des données pour l'exemple
  const characters = [
    { id: 1, name: 'Character 1', image: '/path/to/character1' },
    { id: 2, name: 'Character 2', image: '/path/to/character2' },
  ]

  return (
    <div className="characters-list">
      <div className="list-header">
        <h1>Gestion des Personnages</h1>
        <Link to="/admin/characters/new" className="btn-create">
          Nouveau Personnage
        </Link>
      </div>

      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Image</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {characters.map(character => (
            <tr key={character.id}>
              <td>{character.id}</td>
              <td>{character.name}</td>
              <td>
                <img
                  src={character.image}
                  alt={character.name}
                  style={{ width: '50px' }}
                />
              </td>
              <td>
                <Link to={`/admin/characters/${character.id}/edit`}>
                  Modifier
                </Link>
                <button onClick={() => console.log('Supprimer', character.id)}>
                  Supprimer
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default CharactersList