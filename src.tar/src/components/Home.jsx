import React from 'react'
import { Link } from 'react-router-dom'
import './Home.css'
import Navbar from './Navbar'

function Home() {
  return (

    <div className="showdown-page">
      <Navbar />
      {/* Votre contenu de page d'accueil actuel */}
      <h1>Accueil</h1>
      <Link to="/showdown">Aller au Showdown</Link>
      <Link to="/admin">Aller a test</Link>
    </div>
  )
}

export default Home