import { Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Showdown from './components/Showdown'
import AdminLayout from './components/admin/AdminLayout'
import CharactersList from './components/admin/CharactersList'
//import CharacterForm from './components/admin/CharacterForm'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/showdown" element={<Showdown />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<CharactersList />} />
      </Route>
    </Routes>
  )
}

export default App
